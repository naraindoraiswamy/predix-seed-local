v1.4.0
===================
* Upgrade to Polymer 1.4.0

v1.2.17
===================
* updated bower repos in response to GH Issue

v1.2.16
===================
* forced install of vulcanize to 1.14.8, since 1.14.9 wouldn't work.

v1.2.14
===================
* Updated License

v1.2.13
===================
* resolved merge conflict

v1.2.12
===================
* started merge of develop and master

v1.2.11
===================
* uPatch version

v1.2.10
===================
* Updated manifest to not have logstash and newrelic in it.
