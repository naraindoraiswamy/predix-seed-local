define(['./sample-module', './sample-directive', './sample-filter', './sample-service', './dashboard-controller','./baggagelistCtrl','./checkInCtrl','./MapCtrl','./imageupload','./baggageInput',
    './sample-controller', './predix-asset-service', './predix-user-service', './predix-view-service'], function() {

});
