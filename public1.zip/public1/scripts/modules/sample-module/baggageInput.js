define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    //map controler
    controllers.controller('baggageInputCtrl', ['$scope', '$http', function ($scope, $http) {
   		//for get baggage data
      $http.get('https://airline-postgresql-service.run.aws-usw02-pr.ice.predix.io/getBaggageInfo')
        .then(function (response) {
            $scope.data = response.data;
            console.log("data :" +$scope.data) ;             
        });

        $scope.getBaggageId = function (bagInfo) {
                console.log("bagInfo : " + bagInfo);
                $scope.test = bagInfo;
                if(bagInfo != null && bagInfo != undefined){
                  console.log("uniqueBagId : " +  bagInfo.uniqueBagId);
                 
                 document.getElementById('baggageid').value = bagInfo.uniqueBagId ;
                 document.getElementById('new-imei').value = bagInfo.imei ;
                }     
              };

     $scope.submitForm = function () {
     	alert("in fun call");
	    // var wsUrl = "wss://airline-websocket-server1.run.aws-usw02-pr.ice.predix.io/livestream/messages";
           var wsUrl = "wss://airline-websocket-server.run.aws-usw02-pr.ice.predix.io/livestream/messages";
	  // var wsUrl = "ws://localhost:9192/livestream/messages?authToken=$2a$06$qjh/ni5ynqw1Y53jGJFY2.9QTu/no2IWKQwrUff7qHUXD.zj7xLAO";
            var ws = new WebSocket(wsUrl);
            var timeStampNow = new Date().getTime();
//Mumbai bag Location : 19.096028, 72.873071  //LF1300 - ITT3453
//Spain : 38.466267, -7.028745  // LF1303 - ITT3452
//turkey : 39.190956, 35.409474  //LF1304 - ITT3451

    
	alert("before rfidInfo");
	//{"ID":"LF5240","IMEI":"358696048948767","DATE":1475126188755,"LAT":"33.942429","SPEED":"0","LNG":"-118.404631","TEMP":"18.1700785364","HEAD":"12","BAT":"4.0"}
	    var rfidInfo = {
		ID:document.getElementById('baggageid').value,
		IMEI:document.getElementById('new-imei').value,
		DATE:timeStampNow,
		LAT:document.getElementById('latitude').value,
		LNG:document.getElementById('longitude').value,
		TEMP:document.getElementById('temperature').value,
		BAT:document.getElementById('battery').value,
		SPEED:document.getElementById('speed').value,
		HEAD:document.getElementById('head').value	
	    }	
	    alert("after rfidInfo  " + JSON.stringify(rfidInfo));
	    console.log("rfidInfo " + rfidInfo);
            ws.onopen = function (event) {
                $scope.updateText("Websocket Opened");
                // alert("Websocket opened");
                ws.send(JSON.stringify(rfidInfo));
                $scope.updateText("Data sent to websocket");
            }
            ws.onmessage = function (event) {
                console.log($scope.updateText("Received Data from the websocket: "+event.data));
            }
        }  
        
        $scope.updateText = function(data) {
            document.getElementById('result').innerHTML += data+"<br />";
        }

      }]);
});