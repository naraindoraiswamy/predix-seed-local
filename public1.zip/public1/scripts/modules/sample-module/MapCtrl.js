define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    //map controler
    controllers.controller('MapCtrl', ['$scope', '$http', function ($scope, $http) {
        $scope.init = function () {
            console.log('init');                        

            $http.get('https://airline-postgresql-service.run.aws-usw02-pr.ice.predix.io/getItineraryInfo')  
            .then(function (response) {
                $scope.itinerarydata = response.data;
                console.log("itinerary data :" + JSON.stringify($scope.itinerarydata));
            });

        };
        $scope.init();
        $scope.hideBagDiv = true;
        $scope.hidecheckinDiv = true;      
        $scope.getItineraryId = function (id){
            $scope.imgURL = '';
            $scope.flightdatapoints = [];
            var gmap = document.querySelector('google-map');
            var oldmarker = document.getElementById('currentMarker');
            if( oldmarker !== null){           
                Polymer.dom(gmap).removeChild(oldmarker);
            }
            if(id !== null && id !== undefined){                    

             $http.get('https://airline-postgresql-service.run.aws-usw02-pr.ice.predix.io/getItineraryInfo/'+id)  
             .then(function (response) {                      
                $scope.flightdataObj = response.data.itineraryModelList;
                $scope.selectedBagList = response.data.selectedBaggageIdList;
                console.log("$scope.flightdataObj" +JSON.stringify($scope.flightdataObj));
                console.log("$scope.selectedBagList"+JSON.stringify($scope.selectedBagList));
                if( $scope.selectedBagList.length != 0){                            
                    $scope.hidecheckinDiv = true;  
                    $scope.hideBagDiv = false;                          
                              // alert('plaese, Check-in Your Baggage');

                              var DepartureTime = moment($scope.flightdataObj[0].flightDeparture).format("DD-MM-YYYY | h:mm:ss");
                              var ArrivalTime = moment($scope.flightdataObj[($scope.flightdataObj.length-1)].flightArrival).format("DD-MM-YYYY | h:mm:ss");

                              for(var i=0;i<($scope.flightdataObj.length);i++){
                                if( $scope.flightdataObj[i].hops == 1 ){                                    
                                    var tempObj = {
                                        'imgURL' : '../images/src.png' ,                                       
                                        'Longitude' : $scope.flightdataObj[i].flightSourceLongitude, 
                                        'Latitude' : $scope.flightdataObj[i].flightSourceLatitude,
                                        'contentstring' : 'Source : ' + $scope.flightdataObj[i].source + '\n' 
                                             // + 'Destination : ' + $scope.flightdataObj[i].destination + '\n'
                                             + 'FlightName : ' + $scope.flightdataObj[i].flightName + '\n'
                                             + 'Departure Time : ' + DepartureTime + '\n'
                                             + 'Arrival Time : ' + ArrivalTime                                               
                                         };
                                         $scope.flightdatapoints.push(tempObj);
                                     }
                                     if($scope.flightdataObj[i].hops !== $scope.flightdataObj.length){       
                                        var tempObj = {
                                            'imgURL' : '../images/inter.png' ,                               
                                            'Longitude' : $scope.flightdataObj[i].flightDestinationLongitude, 
                                            'Latitude' : $scope.flightdataObj[i].flightDestinationLatitude ,
                                            'contentstring' : $scope.flightdataObj[i].flightDestination + '\n'
                                            + 'FlightName : ' + $scope.flightdataObj[i].flightName                                                                                                             
                                        };
                                        $scope.flightdatapoints.push(tempObj);
                                    }
                                    if( $scope.flightdataObj[i].hops == $scope.flightdataObj.length ){
                                        var tempObj = {
                                            'imgURL' : '../images/dest.png' ,
                                            'source': $scope.flightdataObj[i].source, 
                                            'destination': $scope.flightdataObj[i].destination,
                                            'Longitude' : $scope.flightdataObj[i].flightDestinationLongitude, 
                                            'Latitude' : $scope.flightdataObj[i].flightDestinationLatitude,
                                        'contentstring' : //'Source : ' + $scope.flightdataObj[i].source + '\n'
                                        'Destination : ' + $scope.flightdataObj[i].destination + '\n'
                                        + 'FlightName : ' + $scope.flightdataObj[i].flightName + '\n'
                                        + 'Departure Time : ' + DepartureTime + '\n'
                                        + 'Arrival Time : ' + ArrivalTime
                                        
                                    };
                                    $scope.flightdatapoints.push(tempObj);
                                }                               
                            }
                            console.log("$scope.flightdatapoints" +JSON.stringify($scope.flightdatapoints));
                        } else {
                            $scope.hidecheckinDiv = false;  
                            $scope.hideBagDiv = true; 
                        }
                    });
}
}

$scope.getBaggageId = function (bagid) {
    if( bagid !== null && bagid !== undefined){
         var gmap = document.querySelector('google-map');
            var oldmarker = document.getElementById('currentMarker');
            if( oldmarker !== null){           
                Polymer.dom(gmap).removeChild(oldmarker);
            }
        $http.get('https://airline-dataingestion.run.aws-usw02-pr.ice.predix.io/getTSData1?BaggageId=' + bagid + '&start=null&end=null')
                    //$http.get('sample-data/timeseriesData.json')
                    .then(function(response) {
                        var responseData = response.data;
                        var output = JSON.parse(JSON.stringify(responseData));
                        var results = [];
                        results = output.tags[0].results;

                        var values = [];
                        values = results[0].values;
                        console.log('values : ' + JSON.stringify(values));
                        var baggagedataValues = JSON.parse(JSON.stringify(values));
                        var latitude = JSON.parse(baggagedataValues[0][1]).LAT;
                        var longitude = JSON.parse(baggagedataValues[0][1]).LNG;

                        console.log(latitude + "" + longitude);

                            //for dynamically adding marker to google map
                            var gmap = document.querySelector('google-map');
                            var marker = document.createElement('google-map-marker');
                            marker.setAttribute('id', 'currentMarker');
                            marker.setAttribute('latitude', latitude);
                            marker.setAttribute('longitude', longitude);                              
                            marker.setAttribute('icon', '../images/baggage.png');
                            marker.setAttribute('animation', 'BOUNCE');
                            var titleString = 'Current Location : \n BagId : '+bagid+'\n Latitude : '+latitude+'\n Longitude : '+longitude
                            var testUrl = 'https://blobstore-aws-sample-demo-sateesh-app.run.aws-usw02-pr.ice.predix.io/v1/blob/'+ bagid +'.jpg';
                            marker.setAttribute('title', titleString);
                            marker.innerHTML = '<img width=\'50\'height=\'50\'src=\''+ testUrl + '\'>'
                            //marker.innerHTML = 'https://blobstore-aws-sample-demo-sateesh-app.run.aws-usw02-pr.ice.predix.io/v1/blob/'+ bagid +'.jpg';
                              //gmap.appendChild(marker);
                              Polymer.dom(gmap).appendChild(marker);
                          });                 
}



}


}]);
});