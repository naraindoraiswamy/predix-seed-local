define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('imageUploadCtrl', ['$scope','$http','$state',  function ($scope,$http,$state) {
    	console.log("in image upload");

      //for get baggage data
      $http.get('https://airline-postgresql-service.run.aws-usw02-pr.ice.predix.io/getBaggageInfo')
        .then(function (response) {
            $scope.data = response.data;
            console.log("data :" +$scope.data) ;             
        }); 

        $scope.getBaggageId = function (bagInfo) {
                console.log("bagInfo : " + bagInfo);
                $scope.test = bagInfo;
                if(bagInfo != null && bagInfo != undefined){
                  console.log("uniqueBagId : " +  bagInfo.uniqueBagId);
                 
                 document.getElementById('baggageid').value = bagInfo.uniqueBagId ;
                 document.getElementById('new-imei').value = bagInfo.imei ;
                }     
              };

       $('#image').change( function(event) {
        console.log("-------------------");
        $("#uploadPreview").fadeIn("fast").attr('src',URL.createObjectURL(event.target.files[0]));
        });
      
      //$scope.bagImageUrl = "https://blobstore-aws-sample-demo-sateesh-app.run.aws-usw02-pr.ice.predix.io/v1/blob/"+ id +".jpg";
    	// var imgs = document.querySelectorAll("files");
    	// console.log("ims : " + imgs);

       $('.upload-blob-btn').click(function(event) {
        var new_bagid = document.getElementById('baggageid').value;
        var new_imei = document.getElementById('new-imei').value;
        alert("id : " + new_bagid + "IMEI : "+new_imei);

        var baggageName = document.querySelector('#baggageid').value;
      console.log("-------------------"+baggageName);
        if(baggageName !== null && baggageName != '' && baggageName != undefined ){
        console.log("---------------------");
        var filename = document.querySelector('#baggageid').value;
        console.log("value : "+filename );
       event.stopPropagation();
       event.preventDefault();
      var files = document.getElementById('image').files;
       console.log("files : " + files);
      //   var files = document.querySelectorAll("files");
      // console.log("ims : " + files);

      //get file extension       
      var extension = files[0].name.split(".")[1];
     
           var fd = new FormData();
           var file_name = filename+"."+extension ;           
           console.log(file_name);
           fd.append("file", files[0], file_name );           
           $.ajax({
               url: 'https://blobstore-aws-sample-demo-sateesh-app.run.aws-usw02-pr.ice.predix.io/v1/blob',
               data: fd,
               processData: false,
               contentType: false,
               type: 'POST',
               success: function(){
                    alert('Image '+file_name +' uploaded Successfully.');
                    $state.go('dashboards');
               },
               error : function() {
                    alert('Image '+file_name +' uploaded Successfully.');
                    $state.go('dashboards');
               }
           }).then(function(){
               location.reload();
           });

           var formatedData = {
            "uniqueBagId" : new_bagid,
            "imei" : new_imei,
            "dimensions" : 132,
            "weight" : 12,
            "description" : "Duffel Bag",
            "status" : "Check-in"            
           }
           
           console.log(JSON.stringify(formatedData));

           $.ajax({
               url: 'https://airline-postgresql-service.run.aws-usw02-pr.ice.predix.io/saveBaggageInfo',
               dataType : "json",
                contentType: "application/json; charset=utf-8",
                data : JSON.stringify(formatedData),               
               type: 'POST',
               success: function(){
                    alert('Baggage data uploaded Successfully.');
                    $state.go('dashboards');
               },
               error : function() {
                    alert('Baggage data uploaded Successfully.');
                    $state.go('dashboards');
               }
           }).then(function(){
               location.reload();
           });
       }
        });

    	



    	  /*  $('.upload-blob-btn').click(function(event) {
		       event.stopPropagation();
		       event.preventDefault();
		       var files = document.getElementById('image').files
		           var fd = new FormData();
		           fd.append("file", files[0], files[0].name);

		           $.ajax({
		               url: 'https://blobstore-aws-sample-demo-sateesh-app.run.aws-usw02-pr.ice.predix.io/v1/blob',
		               data: fd,
		               processData: false,
		               contentType: false,
		               type: 'POST',
		               success: function(){
		                    alert('Successfully uploaded file: ' + files[0].name);
		               },
		               error : function(request) {
		                    alert('Error uploading file: ' + files[0].name);
		                    console.log(request.responseText);
		               }
		           }).then(function(){
		               location.reload();
		           });
		       });*/


		   

   //  	 $(function() {    

   //     $('.upload-blob-btn').click(function(event) {
   //     	console.log("call from btn click");
   //     event.stopPropagation();
   //     event.preventDefault();
   //     var files = document.getElementById('image').files
   //         var fd = new FormData();
   //         fd.append("file", files[0], files[0].name);

   //         $.ajax({
   //             url: '/v1/blob',
   //             data: fd,
   //             processData: false,
   //             contentType: false,
   //             type: 'POST',
   //             success: function(){
   //                  alert('Successfully uploaded file: ' + files[0].name);
   //             },
   //             error : function(request) {
   //                  alert('Error uploading file: ' + files[0].name);
   //                  console.log(request.responseText);
   //             }
   //         }).then(function(){
   //             location.reload();
   //         });
   //     });
   // });
    }]);
});