define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';
    
    // Controller definition
    controllers.controller('checkInCtrl', ['$scope','$http',  function ($scope,$http) {
      $scope.itinerary = true;
      var itineraryId = "";
      var flightNumber = "";  
      
      //get itinerary IDs
      //$http.get('sample-data/checkin.json')
      $http.get('https://airline-postgresql-service.run.aws-usw02-pr.ice.predix.io/getItineraryInfo')  
        .then(function (response) {
            $scope.checkindata = response.data;
            console.log("check in data :" + $scope.checkindata);
        }); 
        $scope.getItineraryId = function (id) {          
           if(id != null && id != undefined){  
            $scope.itinerary = false;
            itineraryId = id;
            console.log("id "+ id);
            $http.get('https://airline-postgresql-service.run.aws-usw02-pr.ice.predix.io/getItineraryInfo/'+id)  
              .then(function (response) {               
                $scope.flightdataObj = response.data.itineraryModelList;
                $scope.selectedBaggageIdList = response.data.selectedBaggageIdList;
                console.log($scope.selectedBaggageIdList);

                $scope.nonSelectedBaggageIdList = response.data.nonSelectedBaggageIdList;
                console.log($scope.nonSelectedBaggageIdList);

                $scope.journeySrc = $scope.flightdataObj[0].source;
                $scope.journeyDest = $scope.flightdataObj[0].destination;               
                $scope.travelStartDate = moment($scope.flightdataObj[0].travelStartDate).format("DD-MM-YYYY | h:mm:ss");
                $scope.flightObj = [];
                for(var i=0;i<$scope.flightdataObj.length;i++){
                  $scope.flightdataObj[i].flightArrival = moment($scope.flightdataObj[i].flightArrival).format("DD-MM-YYYY | h:mm:ss");
                  $scope.flightdataObj[i].flightDeparture = moment($scope.flightdataObj[i].flightDeparture).format("DD-MM-YYYY | h:mm:ss");
                }
                //     var tempObj = {
                //             'flightName': $scope.flightdataObj[i].flightName,
                //             'flightSource': $scope.flightdataObj[i].flightSource;,
                //             'flightDestination' :$scope.flightdataObj[i].flightDestination,
                //             'operatedBy' : $scope.flightdataObj[i].operatedBy,
                //             'flightArrival' : $scope.flightdataObj[i].flightArrival,
                //             'flightDeparture' : $scope.flightdataObj[i].flightDeparture                            
                //         };
                //         $scope.flightObj.push(tempObj);
                //   }
              });
          		
              //$http.get('sample-data/checkin-flight.json')
              // .then(function (response) {
              //     $scope.flightdata = response.data;
              //     for(var i=0;i<$scope.flightdata.length;i++){
              //       if($scope.flightdata[i].itineraryId == id ){                    
              //         $scope.journeySrc = $scope.flightdata[i].journeySrc;
              //         $scope.journeyDest = $scope.flightdata[i].journeyDest;
              //         $scope.flightDetails = $scope.flightdata[i].flightDetails;
              //         console.log("flight details " +$scope.flightDetails[0].flightNumber);
              //         console.log("flight details "+ $scope.flightDetails[0].flightSrc);
              //         }
              //     }
              // }); 

             //for get baggage data
            // $http.get('https://airline-postgresql-service.run.aws-usw02-pr.ice.predix.io/getBaggageInfo')
            //   .then(function (response) {
            //       $scope.baggegeIDdata = response.data;                             
            //   });
              
              $scope.checkinClick = function(){

                 // var flightNumber = [];
                 // $('#itinerary-flightNo :checked').each(function() {                  
                 //   flightNumber.push($(this).val());
                 // });
                 // console.log("flightNumber " + flightNumber);

                var baggageIdList = [];
                 $('#bagid :checked').each(function() {

                   baggageIdList.push($(this).val());
                 });
                 console.log("baggageIdList " + baggageIdList);
                  
                 var checkedInData = {
                    "itineraryId" : itineraryId,                    
                    "uniqueBagId" : baggageIdList                             
                   }

                   console.log(JSON.stringify(checkedInData));
                
  $.ajax({
               url: 'https://airline-postgresql-service.run.aws-usw02-pr.ice.predix.io/mapItineraryAndBag',
               dataType : "json",
                contentType: "application/json; charset=utf-8",
                data : JSON.stringify(checkedInData),               
               type: 'POST',
               success: function(response){
                    alert(response.responseText);                                        
               },
               error : function(response) {
                     alert(response.responseText);
               }
           }).then(function(){
               location.reload();
           });
              }   
              }
            }
  }]);
});