define(['angular', './sample-module'], function(angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('baggagelistCtrl', ['$scope', '$http', function($scope, $http) {
       var responseData = '';
       $scope.baggageitems = [];
        $scope.init = function(){
            $scope.baggagelistData = true;
            $scope.dataItinerary = [];
             $http.get('https://airline-postgresql-service.run.aws-usw02-pr.ice.predix.io/getItineraryInfo')  
              .then(function (response) {
                  $scope.dataItinerary = response.data;
                  //console.log("itinerary data :" + JSON.stringify($scope.itinerarydata));
              });          
        };
        $scope.init();
        // $scope.IsHidden = true;
        // $scope.hideBagDiv = true;
        // $scope.hidecheckinDiv = true;
        // $scope.selectedBagList = [];
        $scope.getItineraryId = function (id){
          $scope.baggageitems = [];
          $scope.baggagelistData = true;
          if(id !== null && id !== undefined){        
          //for get baggage data          
          $scope.selectedBagList = [];
            $http.get('https://airline-postgresql-service.run.aws-usw02-pr.ice.predix.io/getItineraryInfo/'+id)  
             .then(function (response) {
                $scope.selectedBagList = response.data.selectedBaggageIdList;
                console.log("$scope.selectedBagList"+$scope.selectedBagList);
                //  if( $scope.selectedBagList.length != 0){                            
                //     $scope.hidecheckinDiv = true;  
                //     $scope.hideBagDiv = false; 
                // }
                // else {
                //       $scope.hidecheckinDiv = false;  
                //       $scope.hideBagDiv = true; 
                //      } 
            });
           }
        };


        // $scope.ShowHide = function () {
        //         //If DIV is hidden it will be visible and vice versa.
        //         $scope.IsHidden = $scope.IsHidden ? false : true;
        //     };

        $scope.getBaggageId = function(id) {
            
            console.log('in call');
            console.log('id : ' + id);
            $scope.baggageitems = [];
            if(id != null && id != undefined && id != ''){
              $scope.baggagelistData = false;
              $scope.BaggageId = id;
              $scope.getBagInfo(id);
              // $scope.ShowHide();
            }
            
        };

        $scope.getBagInfo = function(id) {          
            console.log('in ---------- getBagInfo : id  ' + id);
            $scope.baggageitems = [];
            $scope.bagImageUrl = 'https://blobstore-aws-sample-demo-sateesh-app.run.aws-usw02-pr.ice.predix.io/v1/blob/' + id + '.jpg';
            var url = 'https://airline-dataingestion.run.aws-usw02-pr.ice.predix.io/getTSData1?BaggageId=' + id + '&start=null&end=null';
            console.log('url : ' + url);
            $http.get(url)
                //$http.get('sample-data/timeseriesData.json')
                .then(function(response) {
                    responseData = response.data;
                    var output = JSON.parse(JSON.stringify(responseData));
                    var results = [];
                    results = output.tags[0].results;

                    var values = [];
                    values = results[0].values;
                    console.log('values : ' + JSON.stringify(values));
                    var baggagedataValues = JSON.parse(JSON.stringify(values));


                    var items = [];
                    for (var i = 0; i < baggagedataValues.length; i++) {
                        var parsedBaggagedata = JSON.parse(baggagedataValues[i][1]);
                        var tempObj = {
                            'Time': new Date(baggagedataValues[i][0]),
                            'Latitude': parsedBaggagedata.LAT,
                            'Longitude': parsedBaggagedata.LNG,
                            'Temperature': parsedBaggagedata.TEMP,
                            'Battery': parsedBaggagedata.BAT,
                            'Speed': parsedBaggagedata.SPEED,
                            'Head': parsedBaggagedata.HEAD
                        };
                        items.push(tempObj);
                    }


                    //scope variables
                    $scope.BaggageId = output.tags[0].name;
                    $scope.IMEI = results[0].attributes.IMEI[0];
                    console.log('items : ' + JSON.stringify(items));
                    $scope.baggageitems = JSON.stringify(items);
                    console.log('items : ' + $scope.baggageitems);


                    // items = [];
                    // for(var i=0; i<response.data.length; i++){
                    //     var tempObj = {
                    //         'key': response.data[i].name,
                    //         'val': response.data[i].flight
                    //     };
                    //     items.push(tempObj);
                    // }
                    // $scope.items = items;
                    // console.log(response.data);
                });
        };
    }]);
});