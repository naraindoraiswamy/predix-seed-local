define(['modules/sample-module/main'], function() {
 
});
/*

$(document).ready(function(){
    $("a.px-app-nav").click(function(event){
        $(this).addClass("selected");
        console.log($(this))
        var elems = document.getElementsByTagName("a.px-app-nav");
        $.each(elems,function(val){
            console.log(val);
            if(val!=$(this)){
                $(val).removeClass('selected');
            }
        })
    })
})
*/
